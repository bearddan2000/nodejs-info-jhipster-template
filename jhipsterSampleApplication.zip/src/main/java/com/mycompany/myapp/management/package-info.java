/**
 * Application management.
 */
package com.mycompany.myapp.management;
